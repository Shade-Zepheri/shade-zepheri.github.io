function getDates() {
    var date, dateToday, monthNum, days, day, year, month;
    date = new Date();
    day = date.getDay();
    dateToday = date.getDate();
    days=["SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"];
    month = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
    monthNum = date.getMonth();
    year = date.getFullYear();
    $('#mn').html(month[monthNum] + " ");
    $('#dy').html(dateToday + " ");
    $('#dd').html(days[day]);
}

function getTimes() {
    var twentyfour, d, h, ampm, hourtxt, minone, mintwo;
    twentyfour = false;
    d = new Date();
    m = d.getMinutes();
    h = d.getHours();
    minone = ["o' clock", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four", "Twenty Five", "Twenty Six", "Twenty Seven", "Twenty Eight", "Twenty Nine", "Thirty", "Thirty One", "Thirty Two", "Thirty Three", "Thirty Four", "Thirty Five", "Thirty Six", "Thirty Seven", "Thirty Eight", "Thirty Nine", "Forty", "Forty One", "Forty Two", "Forty Three", "Forty Four", "Forty Five", "Forty Six", "Forty Seven", "Forty Eight", "Forty Nine", "Fifty", "Fifty One", "Fifty Two", "Fifty Three", "Fifty Four", "Fifty Five", "Fifty Six", "Fifty Seven", "Fifty Eight", "Fifty Nine", "Fifty"];
    ampm = h >= 12 ? 'pm' : 'am';
    hrtxt = (twentyfour === true) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
    $('#hr').html(hrtxt[h]);
    $('#minone').html(minone[m] + " " + ampm);
}

function upifrme() {
  document.getElementById('frme').contentDocument.location.reload(true);
}
function pgMv() {
  if (dsm === true) {
    document.body.addEventListener('touchmove', function (e) {
        e.preventDefault();
    });
  }
}

function setApp() {
}

$(function() {
  $('#tra').attr('title', ra);
  myobj = {
      Phone: "com.apple.mobilephone",
      Camera: "com.apple.camera",
      Snapchat: "com.toyopagroup.picaboo",
      Twitter: "com.atebits.Tweetie2",
      Cydia: "com.saurik.Cydia",
      Spotify: "com.spotify.client"
  };
  $('#apf').attr('title', myobj[fap]).html(fap);
  $('.y').on('touchstart', function() {
    var vw;
    vw = $(this).text();
    $('#' + vw).show();
  });
  $('#br').on('touchstart', function() {
    $('.v').hide();
  });
  $('.x').on('touchstart', function() {
    var app;
    app = $(this).attr('title');
    if (app == "app") {
      openDrawer(drw);
    }
    else {
      openApp(app);
    }
  });
  pgMv();
  getDates();
  getTimes();
  setBat();
  setInterval('getTimes()', 10000);
  setInterval('setBat()', 30000);
  setInterval('getDates()', 1800000);
  setInterval('upifrme()', 3600000);
});
